Advanced Scan
*************

Advanced Scan is a plugin for PEiD.
It will use the 'userdb.txt' for scanning a file and show you all possible signatures sorted by a rating system.


Homepage
--------
http://navig8.to/diablo2oo2
http://diablo2oo2.cjb.net
http://kickme.to/diablo2oo2
http://zor.org/d2k2

Support Board
-------------
http://navig8.to/mp2ksupport