

   Version 1.2 supports

     * InstallShiled modules
     * Microsoft CAB files
     * GK Setup blocks
     * Nullsoft Installer blocks/PiMP files
     * Inno Setup modules
     * Wise Install blocks
     * ActiveMark blocks

   Version 1.1 supports

     * heuristic detection mode
     * HTML/PDF files

   Version 1.0 supports

     * EXE/DLL modules
     * ACE/RAR/ZIP archives
     * Digital Certificates
     * PowerProtect blocks
     * PopCap wrapper