This is a quick sample on a DLL

3 directories in order to follow:
---------------------------------
1 - dumping 2 different based images

2 - dumped files

3 - result with ReloX


NOTE : The example is on a DLL which was not packed. For packed ones,
       you will have to "block" at OEP to dump them.
