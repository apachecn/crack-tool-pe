These are the two dumped DLLs at different bases. You will have to
enter manually their image bases in ReloX because the image base in
the PE header is still the original one.
