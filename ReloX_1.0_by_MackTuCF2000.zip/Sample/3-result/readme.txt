The final result is "original_.dll" which contains a new section ".reloc"
at the end. You will also find the relocations text file of ReloX.
